# Cuidado con modificar este archivo, ya que contiene configuraciones
# globales que afectan a toda la aplicación.

VERSION = "1.0.0"
WINDOW_WIDTH = 750
WINDOW_HEIGHT = 500
WINDOW_TITLE = "Naval Warfare"
