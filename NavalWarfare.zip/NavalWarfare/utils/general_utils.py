import random
from Warship import Warship

def random_rgb():
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
    
