from Warship import Warship

class player:
    def __init__(self, warship: Warship):
        pass